/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
void bubble_sort(int[], int);

int main()
{
    int a[10], n, i;
    scanf("%d", &n);
    printf("Enter the number of elements: %d\n", n);
    for(i = 0; i < n; i++){
        scanf("%d", &a[i]);
    }
    printf("The elements before sorting the array are:\n" );
    for( i = 0; i<n ; i++){
        printf("%d\n", a[i]);
    }
    bubble_sort(a, n);
    printf("Sorted elements in ascending order:\n");
    for( i = 0; i < n; i++){
        printf("%d\n", a[i]);
    }

    return 0;
}
void bubble_sort(int a[], int n)
{
    int i, j , t;
    for(i = 0; i < (n - 1); i++){
        for(j = 0; j < n - i - 1; j++){
            if(a[j] > a[j+1]){
                t = a[j];
                a[j] = a[j + 1];
                a[j + 1] = t;
            }
        }
    }
   
}
