/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void InsertionSort(int a[], int n);
int main()
{
    int i, n, a[10];
    scanf("%d",&n);
    for(i = 0; i < n; i++){
        scanf("%d ", &a[i]);
    }
    InsertionSort(a, n);

    return 0;
}
void InsertionSort(int a[], int n){
    int i, j, temp;
    for(i = 1; i < n; i++){
        temp = a[i];
        for(j = i; j>0&&temp<a[j-1]; j--)
        {
            a[j] = a[j-1];
        }
        a[j] = temp;
    }
    for(i = 0; i <n; i++){
        printf("%d ", a[i]);
    }
}
