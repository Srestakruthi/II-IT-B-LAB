/* Selection Sort */

#include <stdio.h>

void SelectionSort(int a[], int n);
int main()
{
    int a[20];
    int n, i;
    scanf("%d",&n);
    for(i = 0; i < n; i++){
        scanf("%d",&a[i]);
    }
   SelectionSort(a, n);
   
    return 0;
}

void SelectionSort(int a[], int n)
{
    int  i, minimum, j;
    for(i = 0; i < n-1; i++)
    {
        minimum = i;
        for(j = i+1; j < n; j++)
        {
          if( a[j] < a[minimum])
          minimum = j;
        }
    if(minimum != i){
        int temp = a[minimum];
        a[minimum] = a[i];
        a[i] = temp;

}
    
}
printf("Sorted array\n");
for(i = 0;  i < n; i++)
    printf("%d ", a[i]);
}


