/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int RecLinearSearch(int a[], int key, int index, int n);
int main()
{
    int key, i, n=10;
    int a[10] = {11,7,9,16,21,4,15,98,67,31};
    printf("enter the value of key:\n");
    scanf("%d", &key);
    i = RecLinearSearch(a, key, 0, 9);
    if(i != 0){
        printf("%d is found at %d",key,i-1);
    }
    else{
        printf("%d is not found",key);
    }
    return 0;
}
int RecLinearSearch(int a[], int key, int index, int n){
    int i = 0;
    if( index >= n){
        return 0;
    }
    else if( a[index] == key){
        i = index + 1 ;
    }
    else{
        return RecLinearSearch(a, key, index + 1, n);
    }
    return i;
}


