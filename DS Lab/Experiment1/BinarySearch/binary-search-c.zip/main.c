/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main(){
    int a[10] = {4,7,9,11,15,16,21,31,67,98};
    int key, i, mid=0, n=10;
    printf("enter the key value:\n");
    scanf("%d", &key);
    for(i=0; i<n; i++){
        mid = (i +n)/2;
        if(key < a[mid]){
            n = mid - 1;
        }    
        else if(key > a[mid]){
            i = mid + 1;
        }
        else if(key == a[mid]){
            printf("%d is found at %d",key,mid);
            break;
        }
    }
    if(i > n)
    printf("%d not found",key);
    return 0;
}

    
