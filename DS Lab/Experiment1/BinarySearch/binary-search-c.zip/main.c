/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int BinarySearch(int [], int);
int main(){
    int a[10] = {4,7,9,11,15,16,21,31,67,98};
    int key, i, pos;
    printf("enter the key value:\n");
    scanf("%d", &key);
    pos = BinarySearch(a,key);
    if(pos == -1){
        printf("%d is not found",key);
    }
    else{
        printf("%d is found at %d",key,pos);
    }
    return 0;
}
int BinarySearch(int a[], int key)
{
    int mid, pos, i = 0, n = 9;
    while(i <= n)
    {
        mid = (i + n)/2;    
        if(a[mid] == key)
        return mid;
        else if(key > a[mid])
        i = mid + 1;
        else
        n = mid - 1;
    }
    if(i > n)
    return -1;
    return pos;
}
    


    

