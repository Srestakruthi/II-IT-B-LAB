/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int RecBinarySearch(int a[], int key, int low, int high);
int main()
{
    int pos, key;
    int a[10] = {4,7,9,11,15,16,21,31,67,98};
    printf("enter the key:\n");
    scanf("%d", &key);
    pos = RecBinarySearch(a, 0, 9, key);
    if(pos != -1)
    {
        printf("the element %d is found at position %d",key,pos);
    }
    else
    {
        printf("the element %d is not found",key);
    }
    return 0;
}
int RecBinarySearch(int a[], int low, int high, int key)
{
    int mid = 0;
    if(low > high)
    {
        return -1;
    }
    mid = (low + high)/2;
    if(a[mid] == key)
    {
        return mid;
    }
    else if(key < a[mid])
    {
       RecBinarySearch(a, low, mid - 1, key);
    }
    else
    {
       RecBinarySearch(a, mid + 1, high, key);
    }
    
    
}
    
    
